/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starwars2;

import static starwars2.StarWarsCharacter.Fight;
import static starwars2.TheForce.Influence;
import static starwars2.TheForce.moveObject;
import java.util.ArrayList;

/**
 *
 * @author stulujr.local
 */
public class STARWARS2 {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) throws CloneNotSupportedException {
       
       
        
        
        StarWarsCharacter Asajj = new StarWarsCharacter("Asajj","Ventess",30,"F",new TheForce(88,"Dark"),"I told you so");
  
        StarWarsCharacter Bariss = new StarWarsCharacter("Bariss","Offee",30,"F",new TheForce(85,"Light"),"Women Power");
  
        StarWarsCharacter Darth = new StarWarsCharacter("Darth","Vader",42,"M",new TheForce(100,"Dark"),"I am the dark master");
  
        StarWarsCharacter Emperor = new StarWarsCharacter("Emperor","Palpatine",82,"M",new TheForce(97,"Dark"),"Dark Regnis");

        StarWarsCharacter Kylo = new StarWarsCharacter("Kylo","Ren",20,"M",new TheForce(95,"Dark"),"Fuck Yeah");
 
        StarWarsCharacter Luke = new StarWarsCharacter("Luke","Skywalker",19,"M",new TheForce(97,"Light"),"Light has Power"); 
   
        StarWarsCharacter Obi = new StarWarsCharacter("Obi Wan","Kenobi",57,"M",new TheForce(85,"Light"),"I am the hero");
    
        StarWarsCharacter Princess = new StarWarsCharacter("Princess","Leia",19,"F",new TheForce(75,"Light"),"Ohhhhh I won"); 
   
        StarWarsCharacter Rey = new StarWarsCharacter("Rey","",20,"F",new TheForce(96,"Light"),"Give me Some");
 
        StarWarsCharacter Storm = new StarWarsCharacter("Storm","Trooper",25,"M",new TheForce(1,"Dark"),"Yes Sir");
        
        StarWarsCharacter Yoda = new StarWarsCharacter("Yoda","",896,"M",new TheForce(99,"Light")," :-) ");
        
        /*
        * This are the fight methods which are used for the characters to fight
        */
        Fight(Rey,Asajj);
        Fight(Luke,Darth);
        Fight(Luke,Emperor);
        Fight(Bariss,Yoda);
        Fight(Bariss,Obi);
        
        /*
        * This move Object method inorder to move the characters
        */
        moveObject(Asajj,"Kylo");
         /*
        * This move Influence inorder to Infulence the characters
        */
        Influence(Bariss,"Yoda");
        Influence(Storm,"Darth");
       
        /*
        * Creating an arraylist which is used to clone the troopers of the starwar character
        */
        ArrayList<StarWarsCharacter> Stormtrooper= new ArrayList<StarWarsCharacter>();
        StarWarsCharacter Storm1 = Storm.clone();
        StarWarsCharacter Storm2 = Storm.clone();
        StarWarsCharacter Storm3 = Storm.clone();
        StarWarsCharacter Storm4 = Storm.clone();
        StarWarsCharacter Storm5 = Storm.clone();
    
            Storm1.setTauntPhrase("Is that all you got");
            Storm2.setTauntPhrase("Just Easy");
            Storm3.setTauntPhrase("That was quick");
            Storm4.setTauntPhrase("You just weak");
            Storm5.setTauntPhrase("Finish it");
    } 
                                

    
}
