
package starwars2;

/**
 *
 * @author stulujr.local
 */
public class StarWarsCharacter implements Cloneable{
    
    
    //--------------------------------------------------------------------
    //Properties
    //--------------------------------------------------------------------
    
    
    private String FirstName; 
        
        public String getFirstName(){
        
            return this.FirstName;
        }
    
        public void setFirstName(String val){
            
             this.FirstName = val;    
        }
        
       
    private String LastName; 
    
        public String getLastName(){
            
            return this.LastName;  
        }

        public void setLastName(String val){
        
            this.LastName = val;
        }
        
    public String getName(){
    
        return FirstName + " " + LastName;
    }    
    
    
    private int Age;            //in years
        
        public int getAge(){
            
            return this.Age;
        }
    
        public void setAge(int val){
        
            this.Age = val;
        }
        
        
    private String Gender;
    
        public String getGender(){
        
            return this.Gender;
        }
        
        public void setGender(String val){
        
            this.Gender = val;
        }
        
        
    public TheForce Force; 
    
        public TheForce getForce(){
        
            return this.Force;
        }
        
        public void setForce(TheForce val){
        
            this.Force = val;
        }
        
        
    private String TauntPhrase; //words a character uses to taunt others
    
        public String getTauntPhrase(){
        
            return this.TauntPhrase;
        }
    
        public void setTauntPhrase(String val){
        
            this.TauntPhrase = val;
        }
        
    //---------------------------------------------------------------------
    //Constructor 
    //---------------------------------------------------------------------
    // Calling the object properties inulding no argument, first and last name, first last and force name, and at thte last which has all the above object properties 
        
    
    public StarWarsCharacter(){
      }
    public StarWarsCharacter(String aFirstName, String aLastName){
    
        FirstName = aFirstName;
        LastName = aLastName;        
      }
    public StarWarsCharacter(String aFirstName, String aLastName, TheForce aForce){
         
         FirstName = aFirstName;
         LastName = aLastName;
         Force = aForce;
     
      }

     public StarWarsCharacter(String aFirstName, String aLastName, int aAge, String aGender, TheForce aForce, String aTauntPhrase){
         
          setFirstName(aFirstName);
          LastName = aLastName;
          Age = aAge;
          Gender = aGender;
          Force = aForce;
          TauntPhrase = aTauntPhrase;

      }
        

     //--------------------------------------------------------------------
     //Methods
     //--------------------------------------------------------------------
     
   public static void Taunt(StarWarsCharacter firstCharachter){                             // This is a method that used to print a TauntPhrase. 
     
            System.out.println(firstCharachter.getName() + "gloats: " + firstCharachter.getTauntPhrase());
     }
   
   //This is a fight method which makes the two characters fight based on their sides and then strength
   public static void Fight(StarWarsCharacter firstCharachter, StarWarsCharacter secondCharachter){
       
       System.out.println(firstCharachter.getName() + " Fights " + secondCharachter.getName());
       
       //Different Sides 
       if (firstCharachter.getForce().getSide()!= secondCharachter.getForce().getSide()){             
                 
                 //SecondCharachter is greater Strength 
           if (firstCharachter.getForce().getStrength()<secondCharachter.getForce().getStrength()){
               System.out.println(secondCharachter.getName() + " Wins");
               System.out.println(secondCharachter.getName() + " gloats: " + secondCharachter.getTauntPhrase());
               System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
           }
                //FirstCharachter is greater Strength  
           else if (firstCharachter.getForce().getStrength()>secondCharachter.getForce().getStrength()) {
               System.out.println(firstCharachter.getName() + " Wins");
               System.out.println(firstCharachter.getName() + " gloats: " + firstCharachter.getTauntPhrase());
               System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
           } 
               //Both of them equals
           else if (firstCharachter.getForce().getStrength()== secondCharachter.getForce().getStrength()){
               System.out.println(firstCharachter.getName() + "is equal with" + secondCharachter.getName());   
               System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
                            }
       }
              //Same Sides   
       else if(firstCharachter.getForce().getSide()== secondCharachter.getForce().getSide()){
             
              //SecondCharacther is greater 
           if (firstCharachter.getForce().getStrength() < secondCharachter.getForce().getStrength()){
               System.out.println(secondCharachter.getName() + " is stronger in the " + secondCharachter.getForce().getSide() +
                   " side of the force than " + firstCharachter.getName());
               System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
           }
                //FirstCharachter is greater 
               else if (firstCharachter.getForce().getStrength()>secondCharachter.getForce().getStrength()){
               System.out.println(firstCharachter.getName() + " is stronger in the " + firstCharachter.getForce().getSide() +
                   " side of the force than " + secondCharachter.getName()); 
               //System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
                   
           }
               //Both of them are equal
               else if (firstCharachter.getForce().getStrength()== secondCharachter.getForce().getStrength()){
                System.out.println(firstCharachter.getName() + " is equal with" + secondCharachter.getName());   
                System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
           } 
       }
       
   }
  /*
   *This is a clone method used to clone the StarWarsCharacter
   */
 
     @Override
     
    public StarWarsCharacter clone() throws CloneNotSupportedException {                    
        
        return (StarWarsCharacter) super.clone();
    }
       

   
  }    

   
         
         
     
         
