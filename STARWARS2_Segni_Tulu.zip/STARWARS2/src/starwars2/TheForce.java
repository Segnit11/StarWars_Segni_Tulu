
package starwars2;

/**
 *
 * @author stulujr.local
 */
public class TheForce implements Cloneable{
 
    //--------------------------------------------------------------------------
    //PROPERTIES
    //--------------------------------------------------------------------------
    
   public int Strength = 0;    // Creating getters and setters for the Strength property which the characters will have a Strength between 1-100

    public int getStrength() {
        
        return Strength;   
    }

    public void setStrength(int Strength) {
        
        this.Strength = Strength;   
    }


    public String Side;    // Creating getters and setters for the Side property which will be between light and dark 
    
         public String getSide() {
       
             return Side;
    }
        
    public void setSide(String Side) {
       
        this.Side = Side;
    }
    
    //--------------------------------------------------------------------------
    //CONSTRUCTORS
    //--------------------------------------------------------------------------
    
    public TheForce(int aStrength, String aSide){               // Calling the object properties which are the strength and the side 
    
           setStrength(aStrength); 
           setSide(aSide); 
    }
    
    //--------------------------------------------------------------------------
    //METHODS
    //--------------------------------------------------------------------------

    public static void Influence(StarWarsCharacter Character1, String target){          //Creating a method called infulence 
        
        if (Character1.Force.Strength >= 60){
            System.out.println(Character1.getFirstName() + Character1.getLastName()+ " ensures " +target+"these aren't the droids they're looking for.");
            System.out.println("-----------------------------------------------------------------------------------------------------------------------");
    }
        else {
            System.out.println(Character1.getFirstName()+ Character1.getLastName()+ " fails to infulence "+target);
            System.out.println("-----------------------------------------------------------------------------------------------------------------------");
        }
    }
        
   public static void moveObject(StarWarsCharacter Character1, String target){          //Creating a method called moveObject
        
        if (Character1.Force.Strength >= 60){
            System.out.println(Character1.getFirstName()+ Character1.getLastName()+ " flings "+target+" across the room! ");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
    }
        else {
            System.out.println(Character1.getFirstName()+ Character1.getLastName()+ " fails to infulence "+target);
            System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        }
    }
   
   /*
   *This is a clone method used to clone the Force property of the StarWarsCharacter
   */


    @Override
    
    public StarWarsCharacter clone() throws CloneNotSupportedException {
        return (StarWarsCharacter) super.clone();
    }
        
}
    


      
    

