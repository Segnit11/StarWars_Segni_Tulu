
/**
 *This is a Force Tester Class where I tested the three things(Strength Setter, Influence Method, Move Object Method)
 */

package starwars2;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stulujr.local
 * CREDIT TO ELIAS WHO IS A JUNIOR RIGHT NOW. WHO HELPED AND SHOWED ME HOW TO DO THIS FORCE TEST CLASS.
 */
public class TheForceTest {
    
    public TheForceTest() {
    }
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;
    @Before
        
    public void setUpStreams() {
        
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

@After
public void restoreStreams() {
    
    System.setOut(originalOut);
    System.setErr(originalErr);
}

    /**
     * Test of getStrength method, of class TheForce.
     */
//    @Test
//    public void testGetStrength() {
//        System.out.println("getStrength");
//        TheForce instance = null;
//        int expResult = 0;
//        int result = instance.getStrength();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }


    /**
     * Test of setStrength method, of class TheForce. I used 5 tests because I want to check the strength is between 
     * 1 and 100. By making sure that Vader may have the value of 100.
     */
    @Test
    
    public void testSetStrength() {
        
        // First test with the value of 0
        System.out.println("setStrength TESTER:");
        System.out.print("\n");
        System.out.println("Lower bound test");
        int val = 0;
        TheForce instance = new TheForce(90,"Light");
        instance.setStrength(val);
        System.out.print("\n");
        System.out.println("Tested value = "+ val);
        assertEquals(val, instance.getStrength());
        
        //Second test with the value of -10
        System.out.println("\n");
        System.out.print("----------------------------------------------------------------------------------------------------");
        System.out.println("setStrength TESTER:");
        System.out.print("\n");
        System.out.println("Lower bound test");
        int val1 = -10;
        TheForce instance1 = new TheForce(90,"Light");
        instance.setStrength(val1);
        System.out.print("\n");
        System.out.println("Tested value = "+ val1);
        assertEquals(val1, instance.getStrength());

        //Third test with the value of 50
        System.out.println("\n");
        System.out.println("--------------------------------------------------------------------------------------------------");
        System.out.print("\n");
        System.out.println("Interval test");
        int val2 = 50;
        TheForce instance2 = new TheForce(90,"Light");
        instance2.setStrength(val2);
        System.out.print("\n");
        System.out.println("Tested value = "+ val2);
        assertEquals(val2, instance2.getStrength());
        
        //Fourth test with the value of 100
        System.out.println("\n");
        System.out.println("--------------------------------------------------------------------------------------------------");
        System.out.print("\n");
        System.out.println("Upper bound test");
        int val3 = 100;
        TheForce instance3 = new TheForce(100,"Light");
        instance3.setStrength(val3);
        System.out.print("\n");
        System.out.println("Tested value = "+ val3);
        assertEquals(val3, instance3.getStrength());
        
        //Fifth test with the value of 120
        System.out.println("\n");
        System.out.println("--------------------------------------------------------------------------------------------------");
        System.out.print("\n");
        System.out.println("Upper bound test");
        int val4 = 120;
        TheForce instance4 = new TheForce(90,"Light");
        instance4.setStrength(val4);
        System.out.print("\n");
        System.out.println("Tested value = "+ val4);
        System.out.print("\n");
        System.out.print("\n");
        assertEquals(val4, instance4.getStrength());
}
    
    
    @Test
    /**
     * Test of Influence method, of class TheForce. I used three unit testing for this method.
     */
    
    public void testInfluence() {
        //First Test
        System.out.println("\n");
        System.out.println("Influence");
        StarWarsCharacter Character1 = new StarWarsCharacter("Storm","Trooper",25,"M",new TheForce(1,"Dark"),"Yes Sir");
        String target = "Rey"; 
        TheForce.Influence(Character1, target);
        assertEquals("Storm Trooper fails to influence Rey", Character1.getName() + " fails to influence " + target);
        System.out.println("\n");
        
        
        //Second Test
        System.out.println("\n");
        System.out.println("Influence");
        StarWarsCharacter firstCharchter2 = new StarWarsCharacter("Bariss","Offee",30,"F",new TheForce(85,"Light"),"Women Power");
        String target2 = "Yoda";
        TheForce.Influence(firstCharchter2, target2);
        assertEquals("Bariss Offee ensuresYodaaren't the droids they are looking for", firstCharchter2.getName() + " ensures" + target2 + "aren't the droids they are looking for");
        
        //Thrid Test
        System.out.println("\n");
        System.out.println("Influence");
        StarWarsCharacter Character3 = new StarWarsCharacter("Asajj","Ventess",30,"F",new TheForce(88,"Dark"),"I told you so");
        String target3 = "Kylo Ren";
        TheForce.Influence(Character3, target3);
        assertEquals("Asajj Ventess flings Kylo Ren across the room!", Character3.getName() + " flings " + target3 + " across the room!");
    }

    
    /**
     * Test of moveObject method, of class TheForce.  I used three unit testing for this method.
     */
    @Test
    public void testMoveObject() {
        //First Test
        System.out.println("moveObject");
        StarWarsCharacter Character1 = new StarWarsCharacter("Darth","Vader",42,"M",new TheForce(100,"Dark"),"I am the dark master");
        String target = "Obi Wan Kenobi";
        TheForce.moveObject(Character1, target);
        assertEquals("Darth Vader flings Obi Wan Kenobi across the room",Character1.getName() 
                + " flings "+ target + " across the room");
    
        //Second Test 
        System.out.println("\n");
        StarWarsCharacter Character2 = new StarWarsCharacter("Asajj","Ventess",30,"F",new TheForce(88,"Dark"),"I told you so");
        String target2 = "Kylo";
        TheForce.moveObject(Character2, target2);
        assertEquals("Asajj Ventess flings Kylo across the room",Character2.getName() + " flings "
                + target2 + " across the room");
    
        //Third Test
         System.out.println("\n");
        StarWarsCharacter Character3 = new StarWarsCharacter("Yoda","",896,"M",new TheForce(99,"Light")," :-) ");
        String target3 = "Luke Skywalker";
        TheForce.moveObject(Character3, target3);
        assertEquals("Yoda  flings Luke Skywalker across the room",Character3.getName()
                + " flings "+ target3 + " across the room");
    
    }

}
