/**
 * I got a help from my friend(Elias),from my Tutor, From My Professor, Stacks Overflow. 
 */

/**
 *This is a Star Wars Character Tester Class where I tested the tauntPhrase method and FightMethod.
 */
package starwars2;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stulujr.local
 */
public class StarWarsCharacterTest {
    
  
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;
    @Before
        
    public void setUpStreams() {
        
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

@After
public void restoreStreams() {
    
    System.setOut(originalOut);
    System.setErr(originalErr);
}
 public StarWarsCharacterTest() {
    }
 
    @Test
    /**
     * Test of Fight method, of class StarWarsCharacter with different sides fight with different Strength
     */
  
    public void testFight_Different_Sides_fights_With_Different_Strength(){
        
        System.out.println("Fight");
        System.out.println("Light vs Dark. Dark is Stronger");
        StarWarsCharacter firstCharachter = new StarWarsCharacter("Bariss","Offee",30,"F",new TheForce(85,"Light"),"Women Power");
        StarWarsCharacter secondCharachter = new StarWarsCharacter("Kylo","Ren",20,"M",new TheForce(95,"Dark"),"Fuck Yeah");
        StarWarsCharacter.Fight(firstCharachter,secondCharachter);
        assertEquals("Bariss Offee fights Kylo Ren and Kylo Ren wins. Kylo Ren gloats: Fuck Yeah", firstCharachter.getName() 
                + " fights " + secondCharachter.getName() + " and " + secondCharachter.getName() +" "+"wins." 
                      +" "+ secondCharachter.getName() +" " + "gloats:" +" "+ secondCharachter.getTauntPhrase());

    }
   
    @Test
    /**
     * Test of Fight method, of class StarWarsCharacter with the Same Sides, but different Strength
     */
    
    public void testFight_Same_Sides_fights_With_Different_Strength(){
    
        System.out.println("Fight");
        System.out.println("Light vs Light. The winner depends on their Strength");
        StarWarsCharacter firstCharachter1 = new StarWarsCharacter("Luke","Skywalker",19,"M",new TheForce(97,"Light"),"Light has Power"); 
        StarWarsCharacter secondCharachter1 = new StarWarsCharacter("Obi Wan","Kenobi",57,"M",new TheForce(85,"Light"),"I am the hero");
        StarWarsCharacter.Fight(firstCharachter1,secondCharachter1);
        assertEquals("Luke Skywalker is stronger in the Light side of the force than Obi Wan Kenobi", firstCharachter1.getName() + " is stronger in the " 
                + firstCharachter1.getForce().getSide() + " side of the force than " + secondCharachter1.getName());
        
    }
    
   @Test 
    /**
     * Test of Fight method, of class StarWarsCharacter with with different Sides fights with the Strength
     */
   
    public void testFight_Different_Sides_fights_With_Same_Strength(){
    
        System.out.println("Fight");
        System.out.println("Light vs Dark. The winner depends on the Strength");
        StarWarsCharacter firstCharachter2 = new StarWarsCharacter("Emperor","Palpatine",82,"M",new TheForce(97,"Dark"),"Dark Regnis"); 
        StarWarsCharacter secondCharachter2 = new StarWarsCharacter("Luke","Skywalker",19,"M",new TheForce(97,"Light"),"Light has Power");
        //StarWarsCharacter.Fight(firstCharachter2,secondCharachter2);
       
        StarWarsCharacter.Fight(firstCharachter2,secondCharachter2);
        assertEquals("Emperor Palpatine is equal withLuke Skywalker",firstCharachter2.getName() + " is equal with"
                + secondCharachter2.getName());
    }
            
  @Test
    /**
     * Test of Taunt method, of class StarWarsCharacter.
     */
    public void testTaunt() {
        System.out.println("Taunt");
        StarWarsCharacter firstCharachter = new StarWarsCharacter("Asajj","Ventess",30,"F",new TheForce(88,"Dark"),"I told you so");
        String expectedResult = "I told you so";
        String result= firstCharachter.getTauntPhrase();
        
        assertEquals(expectedResult, result);
        
    }
    
}
